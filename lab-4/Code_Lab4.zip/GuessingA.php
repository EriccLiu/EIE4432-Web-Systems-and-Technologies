<?php
   session_start();
   if (!isset($_SESSION["ans"]))  {
	
   } else {
	
   }
   $continue = true;
?>
<!DOCTYPE html>
<html>
<head>
   <title> Guessing game </title>
</head>
<body>
   <h1> Welcome </h1>
   <p> You have chosen the ??? channel for  guessing</p>

   <h2> The answer </h2>

   

   
   <form method="post" action="<?php print htmlspecialchars($_SERVER['PHP_SELF'])?>">
   <p>
      Type your guess here: <input type="text" name="guess" />
      <input type="submit" value="submit"
         <?php if (!$continue) { print("disabled=\"disabled\""); } ?>
      />
   </p>
   </form>

   <h2> Your guess: </h2>



</body>
</html>